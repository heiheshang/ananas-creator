/****************************************************************************
** Meta object code from reading C++ file 'ananasproject.h'
**
** Created: Fri Feb 5 16:55:37 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ananasproject.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ananasproject.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AnanasProjectManager__Internal__AnanasProject[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__AnanasProject[] = {
    "AnanasProjectManager::Internal::AnanasProject\0"
};

const QMetaObject AnanasProjectManager::Internal::AnanasProject::staticMetaObject = {
    { &ProjectExplorer::Project::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasProject,
      qt_meta_data_AnanasProjectManager__Internal__AnanasProject, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::AnanasProject::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::AnanasProject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::AnanasProject::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasProject))
        return static_cast<void*>(const_cast< AnanasProject*>(this));
    typedef ProjectExplorer::Project QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::AnanasProject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef ProjectExplorer::Project QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_AnanasProjectManager__Internal__AnanasProjectFile[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__AnanasProjectFile[] = {
    "AnanasProjectManager::Internal::AnanasProjectFile\0"
};

const QMetaObject AnanasProjectManager::Internal::AnanasProjectFile::staticMetaObject = {
    { &Core::IFile::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasProjectFile,
      qt_meta_data_AnanasProjectManager__Internal__AnanasProjectFile, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::AnanasProjectFile::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::AnanasProjectFile::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::AnanasProjectFile::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasProjectFile))
        return static_cast<void*>(const_cast< AnanasProjectFile*>(this));
    typedef Core::IFile QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::AnanasProjectFile::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef Core::IFile QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_AnanasProjectManager__Internal__AnanasRunConfiguration[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      67,   56,   55,   55, 0x08,
      90,   55,   55,   55, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__AnanasRunConfiguration[] = {
    "AnanasProjectManager::Internal::AnanasRunConfiguration\0"
    "\0scriptFile\0setMainScript(QString)\0"
    "onQmlViewerChanged()\0"
};

const QMetaObject AnanasProjectManager::Internal::AnanasRunConfiguration::staticMetaObject = {
    { &ProjectExplorer::LocalApplicationRunConfiguration::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasRunConfiguration,
      qt_meta_data_AnanasProjectManager__Internal__AnanasRunConfiguration, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::AnanasRunConfiguration::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::AnanasRunConfiguration::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::AnanasRunConfiguration::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasRunConfiguration))
        return static_cast<void*>(const_cast< AnanasRunConfiguration*>(this));
    typedef ProjectExplorer::LocalApplicationRunConfiguration QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::AnanasRunConfiguration::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef ProjectExplorer::LocalApplicationRunConfiguration QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: setMainScript((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: onQmlViewerChanged(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}
static const uint qt_meta_data_AnanasProjectManager__Internal__AnanasRunConfigurationFactory[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__AnanasRunConfigurationFactory[] = {
    "AnanasProjectManager::Internal::AnanasRunConfigurationFactory\0"
};

const QMetaObject AnanasProjectManager::Internal::AnanasRunConfigurationFactory::staticMetaObject = {
    { &ProjectExplorer::IRunConfigurationFactory::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasRunConfigurationFactory,
      qt_meta_data_AnanasProjectManager__Internal__AnanasRunConfigurationFactory, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::AnanasRunConfigurationFactory::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::AnanasRunConfigurationFactory::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::AnanasRunConfigurationFactory::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasRunConfigurationFactory))
        return static_cast<void*>(const_cast< AnanasRunConfigurationFactory*>(this));
    typedef ProjectExplorer::IRunConfigurationFactory QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::AnanasRunConfigurationFactory::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef ProjectExplorer::IRunConfigurationFactory QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE

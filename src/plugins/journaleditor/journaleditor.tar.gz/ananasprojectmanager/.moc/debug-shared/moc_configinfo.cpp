/****************************************************************************
** Meta object code from reading C++ file 'configinfo.h'
**
** Created: Mon Feb 15 17:41:04 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../libananas/configinfo.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'configinfo.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_configInfo[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_configInfo[] = {
    "configInfo\0"
};

const QMetaObject configInfo::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_configInfo,
      qt_meta_data_configInfo, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &configInfo::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *configInfo::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *configInfo::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_configInfo))
        return static_cast<void*>(const_cast< configInfo*>(this));
    if (!strcmp(_clname, "Ui::configInfo"))
        return static_cast< Ui::configInfo*>(const_cast< configInfo*>(this));
    return QDialog::qt_metacast(_clname);
}

int configInfo::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE

/****************************************************************************
** Meta object code from reading C++ file 'ananasexplorersidebar.h'
**
** Created: Mon Feb 15 17:41:02 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ananasexplorersidebar.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ananasexplorersidebar.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AnanasProjectManager__Internal__ananasListViewModel[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__ananasListViewModel[] = {
    "AnanasProjectManager::Internal::ananasListViewModel\0"
};

const QMetaObject AnanasProjectManager::Internal::ananasListViewModel::staticMetaObject = {
    { &QAbstractItemModel::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__ananasListViewModel,
      qt_meta_data_AnanasProjectManager__Internal__ananasListViewModel, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::ananasListViewModel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::ananasListViewModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::ananasListViewModel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__ananasListViewModel))
        return static_cast<void*>(const_cast< ananasListViewModel*>(this));
    return QAbstractItemModel::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::ananasListViewModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractItemModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_AnanasProjectManager__Internal__AnanasExplorerSideBar[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      57,   55,   54,   54, 0x08,
      76,   74,   54,   54, 0x08,
     103,   97,   54,   54, 0x08,
     138,  130,   54,   54, 0x08,
     180,   54,   54,   54, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__AnanasExplorerSideBar[] = {
    "AnanasProjectManager::Internal::AnanasExplorerSideBar\0"
    "\0p\0showmenu(QPoint)\0a\0actionTree(QAction*)\0"
    "index\0doubleClicked(QModelIndex)\0"
    "project\0setCurrentFile(ProjectExplorer::Project*)\0"
    "updateActions()\0"
};

const QMetaObject AnanasProjectManager::Internal::AnanasExplorerSideBar::staticMetaObject = {
    { &QTreeView::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasExplorerSideBar,
      qt_meta_data_AnanasProjectManager__Internal__AnanasExplorerSideBar, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::AnanasExplorerSideBar::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::AnanasExplorerSideBar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::AnanasExplorerSideBar::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasExplorerSideBar))
        return static_cast<void*>(const_cast< AnanasExplorerSideBar*>(this));
    return QTreeView::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::AnanasExplorerSideBar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTreeView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: showmenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 1: actionTree((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 2: doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 3: setCurrentFile((*reinterpret_cast< ProjectExplorer::Project*(*)>(_a[1]))); break;
        case 4: updateActions(); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

/****************************************************************************
** Meta object code from reading C++ file 'ananasnewprojectwizard.h'
**
** Created: Fri Feb 5 16:55:39 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ananasnewprojectwizard.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ananasnewprojectwizard.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AnanasProjectManager__Internal__AnanasNewProjectWizardDialog[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      79,   62,   61,   61, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__AnanasNewProjectWizardDialog[] = {
    "AnanasProjectManager::Internal::AnanasNewProjectWizardDialog\0"
    "\0current,previous\0"
    "updateFilesView(QModelIndex,QModelIndex)\0"
};

const QMetaObject AnanasProjectManager::Internal::AnanasNewProjectWizardDialog::staticMetaObject = {
    { &QWizard::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasNewProjectWizardDialog,
      qt_meta_data_AnanasProjectManager__Internal__AnanasNewProjectWizardDialog, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::AnanasNewProjectWizardDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::AnanasNewProjectWizardDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::AnanasNewProjectWizardDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasNewProjectWizardDialog))
        return static_cast<void*>(const_cast< AnanasNewProjectWizardDialog*>(this));
    return QWizard::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::AnanasNewProjectWizardDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWizard::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: updateFilesView((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        default: ;
        }
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_AnanasProjectManager__Internal__AnanasNewProjectWizard[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_AnanasProjectManager__Internal__AnanasNewProjectWizard[] = {
    "AnanasProjectManager::Internal::AnanasNewProjectWizard\0"
};

const QMetaObject AnanasProjectManager::Internal::AnanasNewProjectWizard::staticMetaObject = {
    { &Core::BaseFileWizard::staticMetaObject, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasNewProjectWizard,
      qt_meta_data_AnanasProjectManager__Internal__AnanasNewProjectWizard, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AnanasProjectManager::Internal::AnanasNewProjectWizard::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AnanasProjectManager::Internal::AnanasNewProjectWizard::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AnanasProjectManager::Internal::AnanasNewProjectWizard::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AnanasProjectManager__Internal__AnanasNewProjectWizard))
        return static_cast<void*>(const_cast< AnanasNewProjectWizard*>(this));
    typedef Core::BaseFileWizard QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int AnanasProjectManager::Internal::AnanasNewProjectWizard::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef Core::BaseFileWizard QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE

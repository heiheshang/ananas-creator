/********************************************************************************
** Form generated from reading UI file 'configinfo.ui'
**
** Created: Fri Feb 5 16:55:23 2010
**      by: Qt User Interface Compiler version 4.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIGINFO_H
#define UI_CONFIGINFO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDateEdit>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QSplitter>
#include <QtGui/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_configInfo
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label_4;
    QTextEdit *commentEdit;
    QSplitter *splitter;
    QLabel *label_3;
    QDateEdit *dateEdit;
    QSplitter *splitter_2;
    QLabel *label;
    QLineEdit *editInfo;
    QLabel *label_2;
    QLineEdit *autorEdit;

    void setupUi(QDialog *configInfo)
    {
        if (configInfo->objectName().isEmpty())
            configInfo->setObjectName(QString::fromUtf8("configInfo"));
        configInfo->resize(473, 224);
        buttonBox = new QDialogButtonBox(configInfo);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(380, 20, 81, 61));
        buttonBox->setOrientation(Qt::Vertical);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label_4 = new QLabel(configInfo);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 131, 451, 17));
        commentEdit = new QTextEdit(configInfo);
        commentEdit->setObjectName(QString::fromUtf8("commentEdit"));
        commentEdit->setGeometry(QRect(10, 151, 451, 61));
        splitter = new QSplitter(configInfo);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(10, 100, 124, 27));
        splitter->setOrientation(Qt::Horizontal);
        label_3 = new QLabel(splitter);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter->addWidget(label_3);
        dateEdit = new QDateEdit(splitter);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        splitter->addWidget(dateEdit);
        splitter_2 = new QSplitter(configInfo);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setGeometry(QRect(10, 0, 361, 97));
        splitter_2->setOrientation(Qt::Vertical);
        label = new QLabel(splitter_2);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial KOI-8"));
        font.setBold(false);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        font.setKerning(false);
        font.setStyleStrategy(QFont::PreferDefault);
        label->setFont(font);
        splitter_2->addWidget(label);
        editInfo = new QLineEdit(splitter_2);
        editInfo->setObjectName(QString::fromUtf8("editInfo"));
        splitter_2->addWidget(editInfo);
        label_2 = new QLabel(splitter_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter_2->addWidget(label_2);
        autorEdit = new QLineEdit(splitter_2);
        autorEdit->setObjectName(QString::fromUtf8("autorEdit"));
        splitter_2->addWidget(autorEdit);

        retranslateUi(configInfo);
        QObject::connect(buttonBox, SIGNAL(accepted()), configInfo, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), configInfo, SLOT(reject()));

        QMetaObject::connectSlotsByName(configInfo);
    } // setupUi

    void retranslateUi(QDialog *configInfo)
    {
        configInfo->setWindowTitle(QApplication::translate("configInfo", "\320\241\320\262\320\276\320\271\321\201\321\202\320\262\320\276 \320\272\320\276\320\275\321\204\320\270\320\263\321\203\321\200\320\260\321\206\320\270\320\270", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("configInfo", "\320\232\320\276\320\274\320\274\320\265\320\275\321\202\320\260\321\200\320\270\320\270", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("configInfo", "\320\224\320\260\321\202\320\260", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("configInfo", "\320\235\320\260\320\270\320\274\320\265\320\275\320\276\320\262\320\260\320\275\320\270\320\265 \320\272\320\276\320\275\321\204\320\270\320\263\321\203\321\200\320\260\321\206\320\270\320\270:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("configInfo", "\320\220\320\262\321\202\320\276\321\200", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class configInfo: public Ui_configInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIGINFO_H

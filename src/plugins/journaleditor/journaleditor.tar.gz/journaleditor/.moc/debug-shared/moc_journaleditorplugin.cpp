/****************************************************************************
** Meta object code from reading C++ file 'journaleditorplugin.h'
**
** Created: Mon Feb 15 17:41:10 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../journaleditorplugin.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'journaleditorplugin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_JOURNALEditor__Internal__JournalEditorPlugin[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      46,   45,   45,   45, 0x08,
      59,   45,   45,   45, 0x08,
      72,   45,   45,   45, 0x08,
      85,   45,   45,   45, 0x08,
     103,   45,   45,   45, 0x08,
     126,  119,   45,   45, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorPlugin[] = {
    "JOURNALEditor::Internal::JournalEditorPlugin\0"
    "\0undoAction()\0redoAction()\0copyAction()\0"
    "selectAllAction()\0updateActions()\0"
    "object\0updateCurrentEditor(Core::IContext*)\0"
};

const QMetaObject JOURNALEditor::Internal::JournalEditorPlugin::staticMetaObject = {
    { &ExtensionSystem::IPlugin::staticMetaObject, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorPlugin,
      qt_meta_data_JOURNALEditor__Internal__JournalEditorPlugin, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &JOURNALEditor::Internal::JournalEditorPlugin::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *JOURNALEditor::Internal::JournalEditorPlugin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *JOURNALEditor::Internal::JournalEditorPlugin::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorPlugin))
        return static_cast<void*>(const_cast< JournalEditorPlugin*>(this));
    typedef ExtensionSystem::IPlugin QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int JOURNALEditor::Internal::JournalEditorPlugin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef ExtensionSystem::IPlugin QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: undoAction(); break;
        case 1: redoAction(); break;
        case 2: copyAction(); break;
        case 3: selectAllAction(); break;
        case 4: updateActions(); break;
        case 5: updateCurrentEditor((*reinterpret_cast< Core::IContext*(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 6;
    }
    return _id;
}
static const uint qt_meta_data_JOURNALEditor__Internal__JournalEditorFactory[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorFactory[] = {
    "JOURNALEditor::Internal::JournalEditorFactory\0"
};

const QMetaObject JOURNALEditor::Internal::JournalEditorFactory::staticMetaObject = {
    { &Core::IEditorFactory::staticMetaObject, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorFactory,
      qt_meta_data_JOURNALEditor__Internal__JournalEditorFactory, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &JOURNALEditor::Internal::JournalEditorFactory::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *JOURNALEditor::Internal::JournalEditorFactory::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *JOURNALEditor::Internal::JournalEditorFactory::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorFactory))
        return static_cast<void*>(const_cast< JournalEditorFactory*>(this));
    typedef Core::IEditorFactory QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int JOURNALEditor::Internal::JournalEditorFactory::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef Core::IEditorFactory QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_JOURNALEditor__Internal__JournalEditorFile[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      50,   44,   43,   43, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorFile[] = {
    "JOURNALEditor::Internal::JournalEditorFile\0"
    "\0block\0provideData(int)\0"
};

const QMetaObject JOURNALEditor::Internal::JournalEditorFile::staticMetaObject = {
    { &Core::IFile::staticMetaObject, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorFile,
      qt_meta_data_JOURNALEditor__Internal__JournalEditorFile, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &JOURNALEditor::Internal::JournalEditorFile::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *JOURNALEditor::Internal::JournalEditorFile::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *JOURNALEditor::Internal::JournalEditorFile::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorFile))
        return static_cast<void*>(const_cast< JournalEditorFile*>(this));
    typedef Core::IFile QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int JOURNALEditor::Internal::JournalEditorFile::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef Core::IFile QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: provideData((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_JOURNALEditor__Internal__JournalEditorInterface[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      49,   48,   48,   48, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorInterface[] = {
    "JOURNALEditor::Internal::JournalEditorInterface\0"
    "\0changed()\0"
};

const QMetaObject JOURNALEditor::Internal::JournalEditorInterface::staticMetaObject = {
    { &Core::IEditor::staticMetaObject, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorInterface,
      qt_meta_data_JOURNALEditor__Internal__JournalEditorInterface, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &JOURNALEditor::Internal::JournalEditorInterface::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *JOURNALEditor::Internal::JournalEditorInterface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *JOURNALEditor::Internal::JournalEditorInterface::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_JOURNALEditor__Internal__JournalEditorInterface))
        return static_cast<void*>(const_cast< JournalEditorInterface*>(this));
    typedef Core::IEditor QMocSuperClass;
    return QMocSuperClass::qt_metacast(_clname);
}

int JOURNALEditor::Internal::JournalEditorInterface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    typedef Core::IEditor QMocSuperClass;
    _id = QMocSuperClass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: changed(); break;
        default: ;
        }
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void JOURNALEditor::Internal::JournalEditorInterface::changed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE

/********************************************************************************
** Form generated from reading UI file 'journaleditor.ui'
**
** Created: Sun Feb 14 19:05:10 2010
**      by: Qt User Interface Compiler version 4.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_JOURNALEDITOR_H
#define UI_JOURNALEDITOR_H

#include <Qt3Support/Q3MimeSourceFactory>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_JournalEdit
{
public:
    QAction *Action;
    QAction *Action_2;
    QTabWidget *tabWidget18;
    QWidget *tab;
    QLabel *textLabel4;
    QTextEdit *eDescription;
    QLineEdit *eName;
    QLabel *textLabel3;
    QLabel *lType;
    QComboBox *cbType;
    QWidget *TabPage;
    QGridLayout *gridLayout;
    QWidget *widget;
    QPushButton *bAddDoc;
    QPushButton *bRemoveDoc;
    QPushButton *bMoveUp;
    QPushButton *bMoveDown;
    QTableWidget *journalDocs;
    QTableWidget *allDocs;
    QWidget *tab1;
    QGridLayout *gridLayout1;
    QTableWidget *tAliases;
    QWidget *TabPage1;
    QGridLayout *gridLayout2;
    QTableWidget *tRoles;

    void setupUi(QWidget *JournalEdit)
    {
        if (JournalEdit->objectName().isEmpty())
            JournalEdit->setObjectName(QString::fromUtf8("JournalEdit"));
        JournalEdit->resize(503, 328);
        Action = new QAction(JournalEdit);
        Action->setObjectName(QString::fromUtf8("Action"));
        Action->setProperty("name", QVariant(QByteArray("Action")));
        Action_2 = new QAction(JournalEdit);
        Action_2->setObjectName(QString::fromUtf8("Action_2"));
        Action_2->setProperty("name", QVariant(QByteArray("Action_2")));
        tabWidget18 = new QTabWidget(JournalEdit);
        tabWidget18->setObjectName(QString::fromUtf8("tabWidget18"));
        tabWidget18->setGeometry(QRect(9, 9, 485, 310));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(tabWidget18->sizePolicy().hasHeightForWidth());
        tabWidget18->setSizePolicy(sizePolicy);
        tabWidget18->setTabPosition(QTabWidget::North);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        textLabel4 = new QLabel(tab);
        textLabel4->setObjectName(QString::fromUtf8("textLabel4"));
        textLabel4->setGeometry(QRect(10, 100, 76, 17));
        textLabel4->setWordWrap(false);
        eDescription = new QTextEdit(tab);
        eDescription->setObjectName(QString::fromUtf8("eDescription"));
        eDescription->setGeometry(QRect(9, 127, 463, 141));
        eName = new QLineEdit(tab);
        eName->setObjectName(QString::fromUtf8("eName"));
        eName->setGeometry(QRect(59, 20, 396, 27));
        textLabel3 = new QLabel(tab);
        textLabel3->setObjectName(QString::fromUtf8("textLabel3"));
        textLabel3->setGeometry(QRect(10, 20, 43, 27));
        textLabel3->setWordWrap(false);
        lType = new QLabel(tab);
        lType->setObjectName(QString::fromUtf8("lType"));
        lType->setGeometry(QRect(10, 60, 211, 23));
        lType->setWordWrap(false);
        cbType = new QComboBox(tab);
        cbType->setObjectName(QString::fromUtf8("cbType"));
        cbType->setGeometry(QRect(230, 60, 221, 23));
        tabWidget18->addTab(tab, QString());
        TabPage = new QWidget();
        TabPage->setObjectName(QString::fromUtf8("TabPage"));
        gridLayout = new QGridLayout(TabPage);
        gridLayout->setSpacing(5);
        gridLayout->setContentsMargins(5, 5, 5, 5);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        widget = new QWidget(TabPage);
        widget->setObjectName(QString::fromUtf8("widget"));
        bAddDoc = new QPushButton(widget);
        bAddDoc->setObjectName(QString::fromUtf8("bAddDoc"));
        bAddDoc->setGeometry(QRect(222, 40, 26, 25));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(bAddDoc->sizePolicy().hasHeightForWidth());
        bAddDoc->setSizePolicy(sizePolicy1);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/arrow_left.png"), QSize(), QIcon::Normal, QIcon::Off);
        bAddDoc->setIcon(icon);
        bRemoveDoc = new QPushButton(widget);
        bRemoveDoc->setObjectName(QString::fromUtf8("bRemoveDoc"));
        bRemoveDoc->setGeometry(QRect(222, 70, 26, 25));
        sizePolicy1.setHeightForWidth(bRemoveDoc->sizePolicy().hasHeightForWidth());
        bRemoveDoc->setSizePolicy(sizePolicy1);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/editdelete.png"), QSize(), QIcon::Normal, QIcon::Off);
        bRemoveDoc->setIcon(icon1);
        bMoveUp = new QPushButton(widget);
        bMoveUp->setObjectName(QString::fromUtf8("bMoveUp"));
        bMoveUp->setGeometry(QRect(222, 100, 26, 25));
        sizePolicy1.setHeightForWidth(bMoveUp->sizePolicy().hasHeightForWidth());
        bMoveUp->setSizePolicy(sizePolicy1);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/arrow_up.png"), QSize(), QIcon::Normal, QIcon::Off);
        bMoveUp->setIcon(icon2);
        bMoveDown = new QPushButton(widget);
        bMoveDown->setObjectName(QString::fromUtf8("bMoveDown"));
        bMoveDown->setGeometry(QRect(222, 130, 26, 25));
        sizePolicy1.setHeightForWidth(bMoveDown->sizePolicy().hasHeightForWidth());
        bMoveDown->setSizePolicy(sizePolicy1);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/arrow_down.png"), QSize(), QIcon::Normal, QIcon::Off);
        bMoveDown->setIcon(icon3);
        journalDocs = new QTableWidget(widget);
        if (journalDocs->columnCount() < 1)
            journalDocs->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        journalDocs->setHorizontalHeaderItem(0, __qtablewidgetitem);
        journalDocs->setObjectName(QString::fromUtf8("journalDocs"));
        journalDocs->setGeometry(QRect(0, 0, 211, 261));
        journalDocs->setColumnCount(1);
        allDocs = new QTableWidget(widget);
        if (allDocs->columnCount() < 1)
            allDocs->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        allDocs->setHorizontalHeaderItem(0, __qtablewidgetitem1);
        allDocs->setObjectName(QString::fromUtf8("allDocs"));
        allDocs->setGeometry(QRect(260, 0, 201, 261));
        allDocs->setSelectionMode(QAbstractItemView::SingleSelection);
        allDocs->setColumnCount(1);

        gridLayout->addWidget(widget, 0, 0, 1, 1);

        tabWidget18->addTab(TabPage, QString());
        tab1 = new QWidget();
        tab1->setObjectName(QString::fromUtf8("tab1"));
        gridLayout1 = new QGridLayout(tab1);
        gridLayout1->setSpacing(5);
        gridLayout1->setContentsMargins(5, 5, 5, 5);
        gridLayout1->setObjectName(QString::fromUtf8("gridLayout1"));
        tAliases = new QTableWidget(tab1);
        if (tAliases->columnCount() < 2)
            tAliases->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tAliases->setHorizontalHeaderItem(0, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tAliases->setHorizontalHeaderItem(1, __qtablewidgetitem3);
        tAliases->setObjectName(QString::fromUtf8("tAliases"));

        gridLayout1->addWidget(tAliases, 0, 0, 1, 1);

        tabWidget18->addTab(tab1, QString());
        TabPage1 = new QWidget();
        TabPage1->setObjectName(QString::fromUtf8("TabPage1"));
        gridLayout2 = new QGridLayout(TabPage1);
        gridLayout2->setSpacing(5);
        gridLayout2->setContentsMargins(5, 5, 5, 5);
        gridLayout2->setObjectName(QString::fromUtf8("gridLayout2"));
        tRoles = new QTableWidget(TabPage1);
        if (tRoles->columnCount() < 2)
            tRoles->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tRoles->setHorizontalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tRoles->setHorizontalHeaderItem(1, __qtablewidgetitem5);
        tRoles->setObjectName(QString::fromUtf8("tRoles"));

        gridLayout2->addWidget(tRoles, 0, 0, 1, 1);

        tabWidget18->addTab(TabPage1, QString());

        retranslateUi(JournalEdit);

        tabWidget18->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(JournalEdit);
    } // setupUi

    void retranslateUi(QWidget *JournalEdit)
    {
        JournalEdit->setWindowTitle(QApplication::translate("JournalEdit", "Journal", 0, QApplication::UnicodeUTF8));
        Action->setIconText(QApplication::translate("JournalEdit", "Action", 0, QApplication::UnicodeUTF8));
        Action_2->setIconText(QApplication::translate("JournalEdit", "Action_2", 0, QApplication::UnicodeUTF8));
        textLabel4->setText(QApplication::translate("JournalEdit", "Description:", 0, QApplication::UnicodeUTF8));
        textLabel3->setText(QApplication::translate("JournalEdit", "Name:", 0, QApplication::UnicodeUTF8));
        lType->setText(QApplication::translate("JournalEdit", "Type:", 0, QApplication::UnicodeUTF8));
        cbType->clear();
        cbType->insertItems(0, QStringList()
         << QApplication::translate("JournalEdit", "Common", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("JournalEdit", "Special", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("JournalEdit", "Othes", 0, QApplication::UnicodeUTF8)
        );
        tabWidget18->setTabText(tabWidget18->indexOf(tab), QApplication::translate("JournalEdit", "Common", 0, QApplication::UnicodeUTF8));
        bAddDoc->setText(QString());
        bRemoveDoc->setText(QString());
        bMoveUp->setText(QString());
        bMoveDown->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = journalDocs->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("JournalEdit", "Documents", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = allDocs->horizontalHeaderItem(0);
        ___qtablewidgetitem1->setText(QApplication::translate("JournalEdit", "Documents", 0, QApplication::UnicodeUTF8));
        tabWidget18->setTabText(tabWidget18->indexOf(TabPage), QApplication::translate("JournalEdit", "Documents", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = tAliases->horizontalHeaderItem(0);
        ___qtablewidgetitem2->setText(QApplication::translate("JournalEdit", "Lang", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = tAliases->horizontalHeaderItem(1);
        ___qtablewidgetitem3->setText(QApplication::translate("JournalEdit", "Name", 0, QApplication::UnicodeUTF8));
        tabWidget18->setTabText(tabWidget18->indexOf(tab1), QApplication::translate("JournalEdit", "Aliases", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem4 = tRoles->horizontalHeaderItem(0);
        ___qtablewidgetitem4->setText(QApplication::translate("JournalEdit", "Read", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem5 = tRoles->horizontalHeaderItem(1);
        ___qtablewidgetitem5->setText(QApplication::translate("JournalEdit", "Write", 0, QApplication::UnicodeUTF8));
        tabWidget18->setTabText(tabWidget18->indexOf(TabPage1), QApplication::translate("JournalEdit", "Access", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class JournalEdit: public Ui_JournalEdit {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_JOURNALEDITOR_H

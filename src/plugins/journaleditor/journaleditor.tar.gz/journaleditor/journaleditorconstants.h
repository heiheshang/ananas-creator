#ifndef JOURNALEDITORCONSTANTS_H
#define JOURNALEDITORCONSTANTS_H
namespace JOURNALEditor {
namespace Constants {

const char * const C_JOURNALEDITOR          = "Journal Editor";
const char * const C_JOURNALEDITOR_MIMETYPE = "application/octet-stream";

} // namespace Constants
} // namespace JournalEditor
#endif // JOURNALEDITORCONSTANTS_H
